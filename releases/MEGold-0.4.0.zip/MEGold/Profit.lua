local _, M = ...
function M.ItemIdentity(link) return type(link) == "string" and link:match("(item:[^|]+)") or nil end
function M.Money(amount)
    return (amount < 0 and "-" or "") .. GetCoinTextureString(math.abs(amount))
end
function M:MarkCollected(purchase)
    if self.vendorRun or self.account.vendorUncertain then return false end
    local found, allocated = false, 0
    for _, entry in ipairs(self.account.purchases) do
        if entry == purchase then found = true end
        if self.ItemIdentity(entry.link) == self.ItemIdentity(purchase.link) then
            allocated = allocated + math.max(0, (entry.collected or 0) - (entry.sold or 0))
        end
    end
    local remaining = purchase.quantity - (purchase.collected or 0)
    if not found or remaining <= 0 or not self.BagTotals then return false end
    local totals = self:BagTotals()
    if (totals[self.ItemIdentity(purchase.link)] or 0) < allocated + remaining then return false end
    purchase.collected, purchase.collectedAt = purchase.quantity, GetServerTime()
    self.account.inventoryTotals = totals
    self:Refresh()
    return true
end
function M:AvailableFlips(link, includeHeld)
    local id, total = self.ItemIdentity(link), 0
    if not id then return 0 end
    for _, purchase in ipairs(self.account.purchases) do
        if self.ItemIdentity(purchase.link) == id and (includeHeld or not purchase.held) then
            total = total + math.max(0, (purchase.collected or 0) - (purchase.sold or 0))
        end
    end
    return total
end
function M:RecordVendorSale(link, quantity, proceeds, flipQuantity)
    local id = self.ItemIdentity(link)
    if not id or quantity < 1 or quantity % 1 ~= 0 or proceeds < 0 or proceeds % 1 ~= 0
        or flipQuantity < 0 or flipQuantity > quantity or flipQuantity % 1 ~= 0 then return nil, "Invalid receipt" end
    if self:AvailableFlips(link, true) < flipQuantity then return nil, "Insufficient collected flip quantity" end
    local receipt = { link = link, quantity = quantity, proceeds = proceeds, flipQuantity = flipQuantity,
        flipProceeds = math.floor(proceeds * flipQuantity / quantity), cost = 0, allocations = {}, at = GetServerTime() }
    local remaining = flipQuantity
    for index, purchase in ipairs(self.account.purchases) do
        if remaining == 0 then break end
        if self.ItemIdentity(purchase.link) == id then
            local sold = purchase.sold or 0
            local count = math.min(remaining, math.max(0, (purchase.collected or 0) - sold))
            if count > 0 then
                -- Allocate remaining cost so partial sales and out-of-order buybacks conserve copper.
                local cost = math.floor((purchase.cost - (purchase.costSold or 0)) * count / (purchase.quantity - sold))
                receipt.allocations[#receipt.allocations + 1] = { purchase = index, quantity = count, cost = cost }
                receipt.cost, remaining = receipt.cost + cost, remaining - count
            end
        end
    end
    for _, allocation in ipairs(receipt.allocations) do
        local purchase = self.account.purchases[allocation.purchase]
        purchase.sold = (purchase.sold or 0) + allocation.quantity
        purchase.costSold = (purchase.costSold or 0) + allocation.cost
    end
    self.account.sales = self.account.sales or {}
    self.account.sales[#self.account.sales + 1] = receipt
    return #self.account.sales
end
function M:ReverseVendorSale(index)
    local receipt = self.account.sales and self.account.sales[index]
    if not receipt or receipt.reversed then return false end
    for _, allocation in ipairs(receipt.allocations) do
        local purchase = self.account.purchases[allocation.purchase]
        purchase.sold = purchase.sold - allocation.quantity
        purchase.costSold = purchase.costSold - allocation.cost
    end
    receipt.reversed, receipt.reversedAt = true, GetServerTime()
    return true
end
function M:GetProfitTally()
    local tally = { flipProceeds = 0, cost = 0, profit = 0, otherProceeds = 0, flipQuantity = 0, otherQuantity = 0 }
    for _, sale in ipairs(self.account.sales or {}) do
        if not sale.reversed then
            tally.flipProceeds = tally.flipProceeds + sale.flipProceeds
            tally.cost = tally.cost + sale.cost
            tally.otherProceeds = tally.otherProceeds + sale.proceeds - sale.flipProceeds
            tally.flipQuantity = tally.flipQuantity + sale.flipQuantity
            tally.otherQuantity = tally.otherQuantity + sale.quantity - sale.flipQuantity
        end
    end
    tally.profit = tally.flipProceeds - tally.cost
    return tally
end
