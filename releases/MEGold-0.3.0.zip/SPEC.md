# MEGold implementation plan

Personal WoW Forever addon. Primary strategy: purchase buyouts below NPC vendor value.
Expandable strategy modules; all monetary calculations use integer copper.

## Agreed behavior

- Scan AH and expose opportunities as soon as the server supplies enough data.
- Default batch: 10 deals, not 10 individual units.
- Buy with real player input; revalidate before purchase. Do not promise unattended batches.
- Filter by profit, percentage return, purchase cap, session budget, gold reserve, rarity, and ignore list.
- Separate commodity quotes from individual auction lots. Never buy across a price cap.
- Record confirmed purchases only; pause uncertain transactions and reconcile before retrying.
- Track collection and vendor sale separately. Expected profit is not realized profit.
- Vendor review permits rarity selection; default Poor/Common. Permanent Never Sell list.
- Track flip quantities conservatively when inventory merges. Never infer ownership from item ID alone.
- Allow items to be held for future AH resale.

## Architecture and milestones

1. Foundation and scanner preview: TOC, saved settings, client checks, item-link valuation,
   cancellable snapshot processing, pending item data, ten-row batches, demo UI.
2. Scan validation: verify Forever replication support/cooldown, item variants, commodity
   representation, inaccessible item data, error paths and throttles in the actual client.
   Add an incremental discovery adapter only if the client supports it reliably.
3. Settings UI and request scheduler: edit all rules, persist settings, prioritize live
   refreshes over discovery; expire old quotes and deduplicate listings.
4. Buy queue: obtain real auction IDs through fresh searches (snapshot indexes are NOT IDs),
   quote commodities, refresh eligibility, reserve budget, player-click purchase,
   success/failure/timeout reconciliation, no duplicate retries.
5. Ledger: character/realm/market keys; confirmed purchase cost, mailbox collection,
   quantity held/sold, realized proceeds, reload recovery and held-for-resale status.
6. Vendor workflow: review bag locations and exact links, rarity controls, Never Sell,
   quantity caps, inventory ambiguity exclusions, verified sale acknowledgments.
7. Launch verification and packaging: scan, item and commodity purchase, AH closure,
   disconnect/reload, mailbox merging, partial sales, unavailable deals, budget boundaries.

## Current implementation boundary

0.3 supports click-driven item purchases and firm commodity quotes.
Editable numeric and rarity filters are implemented with validation and saved settings.
Retained candidates allow changing filters in both directions without rescanning.
Queue handles throttling, stale quotes, batch budget reservation, exact-link matching,
confirmed spending, duplicate auction IDs, closure, timeout and reload locks.
Searches currently inspect the received page; unmatched deals are blocked for skipping.
Commodity totals use sorted price tiers; firm quotes must pass the original deal cap
and current filters. Quotes require explicit confirmation and cannot be used after expiry.
Hooks detect a different UI replacing or cancelling shared commodity quotes.
Transaction review provides audited manual resolution and budget reset controls.
Buying ignore lists and Never Sell IDs are editable in Filters.
Collection tracking and vendor selling remain to build. Mixed-stack policy awaits the
user's choice: skip mixed stacks or split only the tracked flip quantity.
Ledger purchase intent and confirmed purchases persist per character GUID.
Replication produces a server snapshot, not guaranteed streaming listings. Processing
results progressively does not reduce the server's initial snapshot latency.

## Source baseline

Forever interface 16001; verify on launch with GetBuildInfo().
Blizzard API source mirror:
https://github.com/Gethe/wow-ui-source/blob/forever/Interface/AddOns/Blizzard_APIDocumentationGenerated/AuctionHouseDocumentation.lua
Snapshot API uses zero-based indexes. Vendor price is return 11 of C_Item.GetItemInfo.
Source declarations establish signatures, not successful execution on the live client.
