# MEGold

Personal vendor-flip addon for WoW Forever. Version 0.3 adds commodity quotes and transaction review.

## Install

Copy the `MEGold` folder into your Forever client's `Interface/AddOns` folder.
Enable it in the AddOns menu. Interface 16001 targets the known beta API and must be
checked against the launch client. No game installation is modified by this repository.

Open `/meg` or `/megold`. `/meg demo` displays clearly labeled sample deals without
contacting the auction house. Open an auctioneer and press **Scan AH** for real data.
Use **Stop** to cancel local processing. The server may impose a full-scan cooldown.
Hover results for item tooltips; Previous/Next batch shows groups of ten.
Press **Filters** to edit profit, return, purchase cap, budget, reserve, batch size,
and buying rarities. Money fields use copper. Saved filters immediately recheck all
loaded candidates, including previously hidden deals. Confirmed spending counts toward
the character's budget and persists across reloads. **Transactions → Start new budget**
resets spending after the buying batch is finished, while retaining purchase history.
Buying ignore lists and Never Sell lists accept item IDs separated by commas or spaces.
The Never Sell list is saved for the upcoming vendor workflow; selling is not enabled.

## Buying individual item lots

Press **Prepare buying batch** to pause local scanning and select up to the configured
batch size within the remaining budget. Each lot is searched again for a real auction
ID, matching item link/variant and quantity, at no more than its snapshot cost.
Press **Buy Next** for each purchase. Successful server confirmation records the purchase
and refreshes the next deal. **Skip deal** advances past missing or unwanted deals.
Quotes older than ten seconds trigger another search and require a new click.
For commodities, the addon totals available price tiers for the selected quantity.
**Get Quote** requests a firm server quote; **Confirm Buy** purchases it with another click.
The total must remain within the original snapshot price and all current profit/budget
limits. Expired quotes require another request. Changing quotes through another buying
UI invalidates MEGold's quote; conflicted in-flight purchases require manual review.

Transactions are stored under `MEGoldDB.accounts`, keyed by character GUID. Confirmed
purchases record exact links, quantities, costs and timestamps. If a purchase times out,
throws an error, or reloads before confirmation, further buying locks rather than retrying.
A matching late confirmation can resolve it. **Transactions** shows the pending item,
quantity, cost and purchase history. After checking mail, inventory and gold, use
**Verified purchased** or **Verified not purchased** and confirm the review dialog.
Review controls remain disabled while the transaction is still waiting for its response.
Manual decisions are recorded, and confirmed manual purchases count toward the budget.
The addon has not yet been tested in the actual Forever client.

Profit = exact-link vendor unit price × quantity − full lot buyout.
Missing item data stays pending and never becomes a confirmed opportunity.
Listings are snapshots and may already be unavailable.

Collection tracking and vendor selling remain
in [SPEC.md](SPEC.md). Demo data cannot enter the purchase queue. This version can spend
real gold when **Buy Next** or **Confirm Buy** is clicked; it does not sell items.

## Validation

Run `python tests/test_rules.py` when the Python `lupa` package is available.
Tests execute the actual Lua rule module against boundary cases.
Run `python tests/test_queue.py` for mocked-server transaction lifecycle checks.
Run `python tests/test_commodities.py` for quote caps, expiry, interference and reconciliation.
Live-client scan and visual validation are still required.
