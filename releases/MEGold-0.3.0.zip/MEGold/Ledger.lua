local _, M = ...
function M:ResolvePending(entry, purchased)
    if self.account.pending ~= entry or self.queue.phase ~= "uncertain" then return end
    if purchased then
        self:FinishPurchase("manual review")
    else
        entry.status, entry.reviewedAt = "not purchased", GetServerTime()
        self.account.reviews = self.account.reviews or {}
        self.account.reviews[#self.account.reviews + 1] = entry
        self.account.pending = nil
        if entry.auctionID then self.account.bought[entry.auctionID] = true end
        self.queue.index = self.queue.index + 1
        self:PrepareNext()
    end
    self:ShowLedger()
end
StaticPopupDialogs.MEGOLD_RECONCILE = {
    text = "%s", button1 = "Confirm review", button2 = "Cancel", timeout = 0,
    whileDead = true, hideOnEscape = true, preferredIndex = 3,
    OnAccept = function(_, data) M:ResolvePending(data.entry, data.purchased) end,
}
StaticPopupDialogs.MEGOLD_RESET_BUDGET = {
    text = "Start a new MEGold spending budget? Purchase history stays recorded. This resets only the budget counter.",
    button1 = "Start new budget", button2 = "Cancel", timeout = 0, whileDead = true, hideOnEscape = true,
    OnAccept = function()
        if M:QueueBusy() or M.account.pending then return end
        M.account.budgetHistory = M.account.budgetHistory or {}
        table.insert(M.account.budgetHistory, { spent = M.account.spent, closedAt = GetServerTime() })
        M.account.spent = 0
        M:Refilter(); M:ShowLedger()
    end,
}
function M:ReviewPending(purchased)
    local entry = self.account.pending
    if not entry or self.queue.phase ~= "uncertain" then return end
    local text = string.format("%s x%d — %s\n\n%s\nCheck your mailbox, inventory and gold before confirming.",
        entry.name or tostring(entry.itemID), entry.quantity, GetCoinTextureString(entry.cost),
        purchased and "I verified this purchase completed. Record its cost and unlock buying." or
        "I verified this purchase did NOT complete. Unlock buying without recording a purchase.")
    StaticPopup_Show("MEGOLD_RECONCILE", text, nil, { entry = entry, purchased = purchased })
end
function M:ShowLedger()
    if not self.ledgerWindow then
        local f = CreateFrame("Frame", "MEGoldLedger", UIParent, "BasicFrameTemplateWithInset")
        self.ledgerWindow = f
        f:SetSize(760, 490); f:SetPoint("CENTER"); f:SetFrameStrata("DIALOG")
        f.TitleText:SetText("MEGold — Transactions")
        f.summary = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        f.summary:SetPoint("TOPLEFT", 18, -40); f.summary:SetWidth(720); f.summary:SetJustifyH("LEFT")
        f.pending = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        f.pending:SetPoint("TOPLEFT", 18, -75); f.pending:SetWidth(720); f.pending:SetJustifyH("LEFT")
        local function button(label, x, y, action)
            local b = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
            b:SetSize(215, 28); b:SetPoint("TOPLEFT", x, y); b:SetText(label); b:SetScript("OnClick", action)
            return b
        end
        f.yes = button("Verified purchased…", 18, -128, function() M:ReviewPending(true) end)
        f.no = button("Verified not purchased…", 250, -128, function() M:ReviewPending(false) end)
        f.reset = button("Start new budget…", 482, -128, function() StaticPopup_Show("MEGOLD_RESET_BUDGET") end)
        f.history = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        f.history:SetPoint("TOPLEFT", 18, -178); f.history:SetWidth(720); f.history:SetJustifyH("LEFT")
        f.page = 1
        button("Newer", 18, -430, function() f.page = math.max(1, f.page - 1); M:ShowLedger() end)
        button("Older", 250, -430, function() f.page = f.page + 1; M:ShowLedger() end)
    end
    self:RenderLedger()
    self.ledgerWindow:Show()
end
function M:RenderLedger()
    local f, account = self.ledgerWindow, self.account
    if not f or not account then return end
    f.summary:SetText(string.format("Confirmed purchases: %d | Current budget spent: %s", #account.purchases, GetCoinTextureString(account.spent)))
    local entry = account.pending
    f.pending:SetText(entry and string.format("UNRESOLVED: %s x%d | %s | %s", entry.name or tostring(entry.itemID),
        entry.quantity, GetCoinTextureString(entry.cost), self.queue.phase) or "No unresolved purchase.")
    local canReview = entry and self.queue.phase == "uncertain"
    f.yes:SetEnabled(canReview and true or false); f.no:SetEnabled(canReview and true or false)
    f.reset:SetEnabled(not self:QueueBusy() and not entry)
    f.page = math.min(f.page, math.max(1, math.ceil(#account.purchases / 10)))
    local lines = { "Purchase history — page " .. f.page }
    for i = 1, 10 do
        local purchase = account.purchases[#account.purchases - (f.page - 1) * 10 - i + 1]
        if purchase then
            lines[#lines + 1] = string.format("%s x%d | %s | %s", purchase.name or tostring(purchase.itemID),
                purchase.quantity, GetCoinTextureString(purchase.cost), purchase.confirmation or "server")
        end
    end
    f.history:SetText(table.concat(lines, "\n\n"))
end
