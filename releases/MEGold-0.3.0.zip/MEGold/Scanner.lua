local _, M = ...
function M:StopScan()
    self.generation = (self.generation or 0) + 1
    self.scan = nil
    self:SetStatus("Scan stopped. Results are snapshots; refresh before purchasing.")
end
function M:StartScan()
    if self:QueueBusy() then return self:SetStatus("Finish or skip the current buying batch first.") end
    if not self.ahOpen then return self:SetStatus("Open the auction house first.") end
    if self.scan then return end
    if not C_AuctionHouse or not C_AuctionHouse.ReplicateItems then
        return self:SetStatus("This client does not expose the required scan API.")
    end
    self.generation = (self.generation or 0) + 1
    self.results = {}
    self.candidates = {}
    self.scan = { phase = "waiting", pending = {}, checked = 0, total = 0 }
    self:SetStatus("Requesting auction snapshot. Server cooldowns may delay this request.")
    local generation = self.generation
    local ok, err = pcall(C_AuctionHouse.ReplicateItems)
    if not ok then self:StopScan(); return self:SetStatus(tostring(err)) end
    C_Timer.After(30, function()
        if self.scan and self.generation == generation and self.scan.phase == "waiting" then
            self:StopScan()
            self:SetStatus("No snapshot received. The server may be on scan cooldown; try later.")
        end
    end)
end
function M:ValueRow(row)
    -- Item links preserve suffix/variant information; no ID-only valuation fallback.
    if not row.link and row.snapshotIndex then
        row.link = C_AuctionHouse.GetReplicateItemLink(row.snapshotIndex)
    end
    if not row.link then return false end
    local name, _, quality, _, _, _, _, _, _, _, vendor = C_Item.GetItemInfo(row.link)
    if not name or vendor == nil then return false end
    row.name, row.quality, row.vendor = name, quality, vendor
    self.candidates = self.candidates or {}
    self.candidates[#self.candidates + 1] = row
    local metrics = self.Evaluate(row, self.db.settings, GetMoney(), self.account and self.account.spent or 0)
    if metrics then
        row.value, row.profit, row.roi = metrics.value, metrics.profit, metrics.roi
        self.results[#self.results + 1] = row
    end
    return true
end
function M:RetryPending(itemID)
    local scan = self.scan
    if not scan then return end
    for index, row in pairs(scan.pending) do
        if row.itemID == itemID and self:ValueRow(row) then scan.pending[index] = nil end
    end
    self:ScanProgress()
end
function M:ScanProgress()
    local scan = self.scan
    if not scan then return end
    local pending = 0
    for _ in pairs(scan.pending) do pending = pending + 1 end
    self:SetStatus(string.format("%d/%d listings checked | %d deals | %d awaiting item data",
        scan.checked, scan.total, #self.results, pending))
    if scan.phase == "processing" and scan.checked == scan.total then
        scan.phase = "complete"
        if pending == 0 then self.scan = nil end
    elseif scan.phase == "complete" and pending == 0 then self.scan = nil end
end
function M:ReadSnapshot()
    if not self.scan or self.scan.phase ~= "waiting" then return end
    local scan, generation = self.scan, self.generation
    scan.phase = "processing"
    scan.total = C_AuctionHouse.GetNumReplicateItems()
    local index = 0
    local function chunk()
        if self.generation ~= generation or self.scan ~= scan then return end
        local last = math.min(index + 100, scan.total)
        while index < last do
            local info = { C_AuctionHouse.GetReplicateItemInfo(index) }
            local link = C_AuctionHouse.GetReplicateItemLink(index)
            local row = { name = info[1], quantity = info[3], quality = info[4],
                cost = info[10], itemID = info[17], link = link, snapshotIndex = index }
            if row.itemID and row.cost and row.cost > 0 and row.quantity and row.quantity > 0 then
                if not self:ValueRow(row) then
                    scan.pending[index] = row
                    C_Item.RequestLoadItemDataByID(row.itemID)
                end
            end
            index = index + 1
        end
        scan.checked = index
        self:ScanProgress()
        if index < scan.total then C_Timer.After(0, chunk) end
    end
    chunk()
end
function M:Demo()
    if self:QueueBusy() then return self:SetStatus("Finish the buying batch before opening demo data.") end
    self:StopScan()
    self.results = {}
    self.candidates = {}
    for i = 1, 23 do
        local row = { name = "Demo item " .. i, itemID = i, quality = 1,
            quantity = 5, vendor = 100, cost = 200 + i * 5, demo = true }
        self.candidates[#self.candidates + 1] = row
        local metrics = self.Evaluate(row, self.db.settings, 10000000, 0)
        if metrics then
            row.value, row.profit, row.roi = metrics.value, metrics.profit, metrics.roi
            self.results[#self.results + 1] = row
        end
    end
    self:SetStatus("DEMO DATA — no auctions or purchases. Use Scan for real results.")
    self:Show()
end
