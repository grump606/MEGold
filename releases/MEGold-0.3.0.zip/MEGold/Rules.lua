local _, M = ...
-- Pure strategy rules: all money is integer copper; cost is for the entire lot.
function M.Evaluate(deal, settings, money, spent)
    if not deal.vendor or deal.vendor <= 0 then return nil, "unknown vendor value" end
    if not deal.cost or deal.cost <= 0 or not deal.quantity or deal.quantity < 1 then return nil, "invalid lot" end
    if settings.ignored[deal.itemID] then return nil, "ignored" end
    if settings.buyRarities[deal.quality] == false then return nil, "rarity excluded" end
    local value = deal.vendor * deal.quantity
    local profit = value - deal.cost
    if profit <= 0 or profit < settings.minProfit then return nil, "profit too low" end
    if profit / deal.cost * 100 < settings.minReturn then return nil, "return too low" end
    if deal.cost > settings.maxCost then return nil, "purchase limit" end
    if deal.cost + (spent or 0) > settings.budget then return nil, "budget" end
    if deal.cost > money - settings.reserve then return nil, "gold reserve" end
    return { value = value, profit = profit, roi = profit / deal.cost * 100 }
end
