local _, M = ...
local AH = C_AuctionHouse
local function identity(link)
    return link and link:match("(item:[^|]+)")
end
function M:InitializeQueue()
    local key = UnitGUID("player") or (GetRealmName() .. ":" .. UnitName("player"))
    self.db.accounts = self.db.accounts or {}
    self.db.accounts[key] = self.db.accounts[key] or { spent = 0, purchases = {}, bought = {} }
    self.account = self.db.accounts[key]
    self.queue = { phase = self.account.pending and "uncertain" or "idle", rows = {}, index = 1 }
    if self.account.pending then
        self.queue.message = "Unresolved purchase from a previous session. Buying locked; inspect mail and saved ledger."
        self:SetStatus(self.queue.message)
    end
end
function M:QueueBusy()
    return self.queue and self.queue.phase ~= "idle"
end
function M:QueueMessage(text)
    self.queue.message = text
    self:Refresh()
end
function M:BuildBatch()
    if self:QueueBusy() then return end
    if not self.ahOpen then return self:SetStatus("Open the auction house first.") end
    self:StopScan()
    local q = self.queue
    q.rows, q.index, q.phase = {}, 1, "idle"
    local reserved = 0
    for _, row in ipairs(self.results) do
        if not row.demo and self.Evaluate(row, self.db.settings, GetMoney() - reserved, self.account.spent + reserved) then
            q.rows[#q.rows + 1] = row
            reserved = reserved + row.cost
            if #q.rows >= self.db.settings.batchSize then break end
        end
    end
    if #q.rows == 0 then return self:QueueMessage("No real deals meet the remaining budget.") end
    q.phase = "next"
    self:PrepareNext()
end
function M:PrepareNext()
    local q = self.queue
    if self.account.pending then return end
    if self.CancelQuote then self:CancelQuote() end
    q.ready, q.key, q.commodity = nil, nil, nil
    local row = q.rows[q.index]
    if not row then q.phase = "idle"; return self:QueueMessage("Batch complete. Scan again or prepare another batch.") end
    if not self.ahOpen then q.phase = "idle"; return end
    q.key = AH.MakeItemKey(row.itemID, 0, 0, 0)
    local info = AH.GetItemKeyInfo(q.key)
    if not info then
        q.phase = "blocked"
        return self:QueueMessage("Item metadata unavailable. Skip this deal and refresh later.")
    end
    q.commodity = info.isCommodity
    q.phase = "throttled"
    self:SendQueueSearch()
end
function M:SendQueueSearch()
    local q = self.queue
    if q.phase ~= "throttled" or not self.ahOpen then return end
    if not AH.IsThrottledMessageSystemReady() then return self:QueueMessage("Waiting for auction search throttle…") end
    q.phase = "searching"
    local token = {}; q.token = token
    self:QueueMessage("Refreshing " .. q.rows[q.index].name .. "…")
    local ok = pcall(AH.SendSearchQuery, q.key, {}, true)
    if not ok then q.phase = "blocked"; return self:QueueMessage("Search rejected. Skip and refresh later.") end
    C_Timer.After(15, function()
        if q.token == token and q.phase == "searching" then
            q.phase = "blocked"; self:QueueMessage("Search timed out. Skip and refresh later.")
        end
    end)
end
function M:QueueResults(key)
    local q = self.queue
    if q.phase ~= "searching" or q.commodity or not key or key.itemID ~= q.key.itemID then return end
    local wanted = q.rows[q.index]
    local best
    for i = 1, AH.GetNumItemSearchResults(q.key) do
        local result = AH.GetItemSearchResultInfo(q.key, i)
        if result and not result.containsOwnerItem and not result.containsAccountItem
            and not self.account.bought[result.auctionID]
            and identity(result.itemLink) == identity(wanted.link) and identity(wanted.link)
            and result.quantity == wanted.quantity and result.buyoutAmount and result.buyoutAmount > 0
            and result.buyoutAmount <= wanted.cost then
            local name, _, quality, _, _, _, _, _, _, _, vendor = C_Item.GetItemInfo(result.itemLink)
            local deal = { itemID = wanted.itemID, name = name, link = result.itemLink, quality = quality,
                quantity = result.quantity, vendor = vendor, cost = result.buyoutAmount, auctionID = result.auctionID }
            if self.Evaluate(deal, self.db.settings, GetMoney(), self.account.spent)
                and (not best or deal.cost < best.cost) then best = deal end
        end
    end
    if not best then
        -- Partial pages may not contain a match. Never infer availability or buy an alternative variant.
        q.phase = "blocked"
        return self:QueueMessage("No matching profitable lot on this results page. Skip this deal.")
    end
    q.ready, q.phase, q.readyAt = best, "ready", GetTime()
    self:QueueMessage(string.format("%d/%d: %s x%d — cost %s. Click Buy Next.", q.index, #q.rows,
        best.name, best.quantity, GetCoinTextureString(best.cost)))
end
function M:BuyNext()
    local q = self.queue
    if q.phase ~= "ready" or not q.ready or not self.ahOpen or self.account.pending then return end
    if q.commodity then return self:BuyCommodity() end
    local deal = q.ready
    if GetTime() - q.readyAt > 10 then return self:PrepareNext() end
    local current
    for i = 1, AH.GetNumItemSearchResults(q.key) do
        local result = AH.GetItemSearchResultInfo(q.key, i)
        if result and result.auctionID == deal.auctionID then current = result; break end
    end
    if not current or current.buyoutAmount ~= deal.cost or current.quantity ~= deal.quantity
        or identity(current.itemLink) ~= identity(deal.link) or current.containsOwnerItem or current.containsAccountItem then
        return self:PrepareNext()
    end
    if not self.Evaluate(deal, self.db.settings, GetMoney(), self.account.spent) then
        q.phase = "blocked"; return self:QueueMessage("Deal no longer meets your filters or budget. Skip it.")
    end
    -- Save intent before sending. A timeout/reload must never silently retry a purchase.
    local entry = {}
    for k, v in pairs(deal) do entry[k] = v end
    entry.status, entry.createdAt = "pending", GetServerTime()
    self.account.pending = entry
    q.phase = "purchasing"
    self:QueueMessage("Waiting for purchase confirmation…")
    local ok = pcall(AH.PlaceBid, deal.auctionID, deal.cost)
    if not ok then q.phase = "uncertain"; return self:QueueMessage("Purchase call failed. Buying locked until reconciled.") end
    C_Timer.After(15, function()
        if self.account.pending == entry then
            q.phase = "uncertain"; self:QueueMessage("Purchase unconfirmed. Buying locked; inspect mail before reconciliation.")
        end
    end)
end
function M:PurchaseConfirmed(auctionID)
    local entry = self.account.pending
    if not entry or entry.commodity or entry.auctionID ~= auctionID then return end
    self:FinishPurchase("server")
end
function M:FinishPurchase(source)
    local entry = self.account.pending
    if not entry then return end
    entry.status, entry.confirmedAt = "purchased", GetServerTime()
    entry.confirmation = source
    self.account.purchases[#self.account.purchases + 1] = entry
    if entry.auctionID then self.account.bought[entry.auctionID] = true end
    self.account.spent = self.account.spent + entry.cost
    self.account.pending = nil
    self.queue.index = self.queue.index + 1
    self:PrepareNext()
end
function M:SkipDeal()
    local q = self.queue
    if self.account.pending or q.phase == "idle" then return end
    q.token = nil
    q.index = q.index + 1
    self:PrepareNext()
end
function M:CloseQueue()
    local q = self.queue
    if self.CancelQuote then self:CancelQuote() end
    q.token, q.ready = nil, nil
    q.phase = self.account.pending and "uncertain" or "idle"
    self:QueueMessage(self.account.pending and "AH closed with an unresolved purchase. Buying locked." or "Buying batch cancelled because the AH closed.")
end
local events = CreateFrame("Frame")
events:RegisterEvent("ITEM_SEARCH_RESULTS_UPDATED")
events:RegisterEvent("ITEM_SEARCH_RESULTS_ADDED")
events:RegisterEvent("AUCTION_HOUSE_THROTTLED_SYSTEM_READY")
events:RegisterEvent("AUCTION_HOUSE_PURCHASE_COMPLETED")
events:SetScript("OnEvent", function(_, event, arg)
    if not M.account then return end
    if event == "AUCTION_HOUSE_PURCHASE_COMPLETED" then M:PurchaseConfirmed(arg)
    elseif event == "AUCTION_HOUSE_THROTTLED_SYSTEM_READY" then M:SendQueueSearch()
    elseif not M.queue.commodity then M:QueueResults(arg) end
end)
