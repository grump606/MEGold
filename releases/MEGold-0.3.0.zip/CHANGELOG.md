# Changelog

## 0.3.0
- Commodity price-tier totals, firm server quotes, and click confirmation.
- Price caps, expiry checks, and detection of other commodity buying UI activity.
- Transactions window, purchase history, reviewed pending transactions, and budget reset.
- Editable buying exclusions and persistent Never Sell IDs.
- Tests for quotes, recovery and conflicting UI actions.

## 0.2.0
- Refreshed individual auction IDs, click-driven buying batches, persistent purchase intents.
- Confirmed-spend ledger, stale quote checks and uncertain-purchase locks.
- Saved numeric and rarity filters with reversible refiltering.

## 0.1.0
- Snapshot scanner, vendor-profit rules, paged results and demo mode.
