local _, M = ...
local Bags = C_Container
local function lastBag() return NUM_TOTAL_EQUIPPED_BAG_SLOTS or NUM_BAG_SLOTS or 4 end
local function same(a, b)
    return a and b and M.ItemIdentity(a.link) == M.ItemIdentity(b.link) and a.quantity == b.quantity and a.price == b.price
end
local function totalsSame(a, b)
    for id, quantity in pairs(a) do if (b[id] or 0) ~= quantity then return false end end
    for id, quantity in pairs(b) do if (a[id] or 0) ~= quantity then return false end end
    return true
end
function M:BagTotals()
    local totals = {}
    for bag = 0, lastBag() do
        for slot = 1, Bags.GetContainerNumSlots(bag) do
            local item = Bags.GetContainerItemInfo(bag, slot)
            local id = item and self.ItemIdentity(item.hyperlink)
            if id then totals[id] = (totals[id] or 0) + item.stackCount end
        end
    end
    return totals
end
function M:ReadBuyback()
    local rows = {}
    for index = 1, GetNumBuybackItems() do
        local _, _, price, quantity = GetBuybackItemInfo(index)
        local link = GetBuybackItemLink(index)
        if not link or not price or not quantity then return nil end
        rows[#rows + 1] = { link = link, price = price, quantity = quantity }
    end
    return rows
end
function M:VendorUncertain(reason)
    self.account.vendorUncertain = { reason = reason, at = GetServerTime() }
    self.vendorRun = nil
    self:SetStatus("Vendor accounting needs review: " .. reason .. ". Sell Flips is locked.")
end
function M:ObserveVendor()
    if not self.merchantOpen or not self.vendorSnapshot or self.account.vendorUncertain then return end
    local before, after = self.vendorSnapshot, self:ReadBuyback()
    if not after then return end
    local money, totals = GetMoney(), self:BagTotals()
    local old, overlap = before.rows, 0
    for count = math.min(#old, #after), 0, -1 do
        local matches = true
        for i = 1, count do if not same(old[#old - count + i], after[i]) then matches = false; break end end
        if matches then overlap = count; break end
    end
    local unchanged = #old == #after and overlap == #old
    -- A full ring of identical buyback entries can still be confirmed for our own
    -- single in-flight sale using its saved intent, exact bag decrease and gold gain.
    if unchanged and #after > 0 and self.vendorRun and self.vendorRun.phase == "selling" then
        local row = self.vendorRun.rows[self.vendorRun.index]
        local id = self.ItemIdentity(row.link)
        if money - before.money == row.vendor * row.quantity
            and (before.totals[id] or 0) - (totals[id] or 0) == row.quantity
            and same(after[#after], {link = row.link, price = row.vendor * row.quantity, quantity = row.quantity}) then
            unchanged, overlap = false, #after - 1
        end
    end
    local removedIndex
    if #after == #old - 1 then
        for skipped = 1, #old do
            local matches = true
            for i = 1, #after do if not same(old[i < skipped and i or i + 1], after[i]) then matches = false; break end end
            if matches then
                -- Identical entries may have different cost allocations: do not guess which was bought back.
                if removedIndex then removedIndex = false; break end
                removedIndex = skipped
            end
        end
    end
    if removedIndex then
        local removed = old[removedIndex]
        local id = self.ItemIdentity(removed.link)
        if money - before.money ~= -removed.price or (totals[id] or 0) - (before.totals[id] or 0) ~= removed.quantity then return end
        if removed.receipt then self:ReverseVendorSale(removed.receipt) end
        for i = 1, #after do after[i].receipt = old[i < removedIndex and i or i + 1].receipt end
    elseif not unchanged and #after > overlap then
        local revenue, quantities = 0, {}
        for i = overlap + 1, #after do
            local row, id = after[i], self.ItemIdentity(after[i].link)
            if not id then return end
            revenue = revenue + row.price
            quantities[id] = (quantities[id] or 0) + row.quantity
        end
        -- Wait for both bag and money events before recognizing a receipt.
        if money - before.money ~= revenue then return end
        for id, quantity in pairs(quantities) do
            if (before.totals[id] or 0) - (totals[id] or 0) ~= quantity then return end
        end
        for i = 1, overlap do after[i].receipt = old[#old - overlap + i].receipt end
        for i = overlap + 1, #after do
            local row = after[i]
            local flipQuantity = math.min(row.quantity, self:AvailableFlips(row.link, true))
            row.receipt = self:RecordVendorSale(row.link, row.quantity, row.price, flipQuantity)
            if not row.receipt then return self:VendorUncertain("sale could not be allocated to its purchases") end
        end
    elseif unchanged then
        -- Full identical buyback lists cannot establish which item was sold.
        if money > before.money then
            for id, quantity in pairs(before.totals) do
                if (totals[id] or 0) < quantity then return self:VendorUncertain("identical buyback entries prevented sale identification") end
            end
        end
        if money ~= before.money or not totalsSame(totals, before.totals) then return end
        for i = 1, #after do after[i].receipt = old[i].receipt end
    else
        return
    end
    self.vendorSnapshot = { rows = after, money = money, totals = totals }
    self.account.inventoryTotals = totals
    self.account.buybackRows = after
    if self.vendorRun and self.vendorRun.phase == "selling" then
        local run, row = self.vendorRun, self.vendorRun.rows[self.vendorRun.index]
        if (totals[self.ItemIdentity(row.link)] or 0) == run.beforeCount - row.quantity then
            self.account.vendorPending = nil
            run.index, run.phase = run.index + 1, "next"
            C_Timer.After(0.2, function() if self.vendorRun == run then self:VendorStep() end end)
        end
    end
    self:Refresh()
end
function M:ScheduleVendorObservation()
    if not self.merchantOpen then return end
    local token = {}; self.vendorObservation = token
    C_Timer.After(0.2, function()
        if self.vendorObservation ~= token or not self.merchantOpen then return end
        self:ObserveVendor()
        local snapshot = self.vendorSnapshot
        local after = self:ReadBuyback()
        local changed = after and (#after ~= #snapshot.rows)
        if after and not changed then for i = 1, #after do if not same(after[i], snapshot.rows[i]) then changed = true; break end end end
        -- No broad money-delta accounting: repairs, purchases and quest gold are not sales.
        local unsettled = GetMoney() ~= snapshot.money or not totalsSame(self:BagTotals(), snapshot.totals)
        if changed or unsettled then
            C_Timer.After(2, function()
                if self.merchantOpen and self.vendorObservation == token and self.vendorSnapshot == snapshot then
                    self:ObserveVendor()
                    if self.vendorSnapshot == snapshot then
                        if changed then self:VendorUncertain("buyback changes did not match bag and gold changes")
                        elseif not self.vendorRun then
                            -- Non-sale money/inventory activity has settled without changing buyback.
                            local totals = self:BagTotals()
                            if self.ReconcileInventory then self:ReconcileInventory(totals) end
                            self.vendorSnapshot = { rows = after, money = GetMoney(), totals = totals }
                        end
                    end
                end
            end)
        end
    end)
end
function M:VendorEligible(bag, slot)
    local item = Bags.GetContainerItemInfo(bag, slot)
    if not item or item.isLocked or item.isBound or item.hasNoValue or not item.hyperlink then return nil end
    if self.db.settings.neverSell[item.itemID] then return nil end
    local name, _, quality, _, _, _, _, _, _, _, vendor = C_Item.GetItemInfo(item.hyperlink)
    if not name or not vendor or vendor <= 0 or not self.db.settings.sellRarities[quality] then return nil end
    if not Bags.GetContainerItemEquipmentSetInfo or Bags.GetContainerItemEquipmentSetInfo(bag, slot) then return nil end
    return { bag = bag, slot = slot, link = item.hyperlink, itemID = item.itemID, name = name,
        stackCount = item.stackCount, vendor = vendor, quality = quality }
end
function M:BuildVendorReview()
    if self.vendorRun or self.account.vendorUncertain then return end
    self:ObserveVendor()
    local rows, remaining = {}, {}
    for bag = 0, lastBag() do
        for slot = 1, Bags.GetContainerNumSlots(bag) do
            local row = self:VendorEligible(bag, slot)
            if row then
                local id = self.ItemIdentity(row.link)
                if remaining[id] == nil then remaining[id] = self:AvailableFlips(row.link) end
                row.quantity = math.min(row.stackCount, remaining[id])
                if row.quantity > 0 then rows[#rows + 1] = row; remaining[id] = remaining[id] - row.quantity end
            end
        end
    end
    self.vendorReview = rows
    return rows
end
function M:StartVendorSale()
    if not self.merchantOpen or self.vendorRun or self.account.vendorUncertain or not self.vendorReview then return end
    local selected = {}
    for _, row in ipairs(self.vendorReview) do if not row.excluded then selected[#selected + 1] = row end end
    self.vendorRun = { rows = selected, index = 1, phase = "next" }
    self.vendorReview = nil
    self:VendorStep()
end
function M:StopVendorSale(message)
    self.vendorRun = nil
    self:SetStatus(message or "Vendor sale stopped.")
end
function M:VendorStep()
    local run = self.vendorRun
    if not run then return end
    if not self.merchantOpen or not MerchantFrame or not MerchantFrame:IsShown() or InCombatLockdown()
        or (InRepairMode and InRepairMode()) or GetCursorInfo() then return self:StopVendorSale("Vendor sale paused: merchant, combat, repair or cursor state changed.") end
    local row = run.rows[run.index]
    if not row then return self:StopVendorSale("Reviewed flips sold. Profit tally updated.") end
    local current = self:VendorEligible(row.bag, row.slot)
    if not current or self.ItemIdentity(current.link) ~= self.ItemIdentity(row.link) or current.stackCount ~= row.stackCount
        or current.vendor ~= row.vendor or self:AvailableFlips(row.link) < row.quantity then
        return self:StopVendorSale("Inventory or eligibility changed. Review flips again.")
    end
    if row.stackCount > row.quantity then
        local freeBag, freeSlot
        for bag = 0, lastBag() do
            local _, family = Bags.GetContainerNumFreeSlots(bag)
            if family == 0 then
                for slot = 1, Bags.GetContainerNumSlots(bag) do
                    if not Bags.GetContainerItemInfo(bag, slot) then freeBag, freeSlot = bag, slot; break end
                end
            end
            if freeBag then break end
        end
        if not freeBag then return self:StopVendorSale("A free general-purpose bag slot is needed to split flips.") end
        local ok = pcall(Bags.SplitContainerItem, row.bag, row.slot, row.quantity)
        local cursorType, _, cursorLink = GetCursorInfo()
        if not ok or cursorType ~= "item" or self.ItemIdentity(cursorLink) ~= self.ItemIdentity(row.link)
            or Bags.GetContainerItemInfo(freeBag, freeSlot) then return self:StopVendorSale("Split could not be verified. Check your cursor; nothing was sold.") end
        local placed = pcall(Bags.PickupContainerItem, freeBag, freeSlot)
        if not placed or GetCursorInfo() then return self:StopVendorSale("Could not place the split stack. Check your cursor; nothing was sold.") end
        local originalBag, originalSlot, originalCount = row.bag, row.slot, row.stackCount
        run.phase = "splitting"
        C_Timer.After(0.3, function()
            if self.vendorRun ~= run then return end
            local source = Bags.GetContainerItemInfo(originalBag, originalSlot)
            local target = Bags.GetContainerItemInfo(freeBag, freeSlot)
            if not source or not target or source.stackCount ~= originalCount - row.quantity or target.stackCount ~= row.quantity
                or self.ItemIdentity(source.hyperlink) ~= self.ItemIdentity(row.link) or self.ItemIdentity(target.hyperlink) ~= self.ItemIdentity(row.link) then
                return self:StopVendorSale("Split result changed. Review your bags before selling.")
            end
            row.bag, row.slot, row.stackCount = freeBag, freeSlot, row.quantity
            run.phase = "next"
            self:VendorStep()
        end)
        return
    end
    self:ObserveVendor()
    if self.account.vendorUncertain then return self:StopVendorSale("Vendor accounting needs review.") end
    run.beforeCount = (self:BagTotals()[self.ItemIdentity(row.link)] or 0)
    run.phase = "selling"
    self.account.vendorPending = { link = row.link, quantity = row.quantity, at = GetServerTime() }
    if self.LogState then self:LogState("vendor-intent", "Sell reviewed stack", {itemID = row.itemID, quantity = row.quantity, bag = row.bag, slot = row.slot, expected = row.vendor * row.quantity}) end
    local ok, err = pcall(Bags.UseContainerItem, row.bag, row.slot)
    if not ok and self.LogState then self:LogState("api-error", tostring(err), {operation = "UseContainerItem"}) end
    if not ok then return self:VendorUncertain("sale call failed; inspect inventory and vendor buyback") end
    C_Timer.After(4, function()
        if self.vendorRun == run and run.phase == "selling" then
            self:ObserveVendor()
            if self.vendorRun == run and run.phase == "selling" then self:VendorUncertain("sale confirmation timed out") end
        end
    end)
end
function M:ExcludeUncertainVendorActivity()
    if not self.account.vendorUncertain or self.vendorRun or not self.merchantOpen then return end
    self.account.vendorReviews = self.account.vendorReviews or {}
    table.insert(self.account.vendorReviews, self.account.vendorUncertain)
    -- Unknown sales must not leave potentially consumed flips eligible for automatic selling.
    for _, purchase in ipairs(self.account.purchases) do
        if (purchase.collected or 0) > (purchase.sold or 0) then
            purchase.collected, purchase.held = purchase.sold or 0, true
        end
    end
    self.account.vendorUncertain = nil
    self.account.vendorPending = nil
    self.vendorSnapshot = { rows = self:ReadBuyback() or {}, money = GetMoney(), totals = self:BagTotals() }
    self.account.inventoryTotals = self.vendorSnapshot.totals
    self.account.buybackRows = self.vendorSnapshot.rows
    self.vendorReview = nil
    self:SetStatus("Uncertain activity excluded from totals. Remaining flips were placed on hold; verify collection before releasing them.")
end
local events = CreateFrame("Frame")
for _, event in ipairs({ "MERCHANT_SHOW", "MERCHANT_CLOSED", "MERCHANT_UPDATE", "PLAYER_MONEY", "BAG_UPDATE_DELAYED" }) do events:RegisterEvent(event) end
events:SetScript("OnEvent", function(_, event)
    if not M.account then return end
    if event == "MERCHANT_SHOW" then
        M.merchantOpen = true
        local rows = M:ReadBuyback() or {}
        local saved = M.account.buybackRows or {}
        if #rows == #saved then
            local matches = true
            for i = 1, #rows do if not same(rows[i], saved[i]) then matches = false; break end end
            if matches then for i = 1, #rows do rows[i].receipt = saved[i].receipt end end
        end
        M.vendorSnapshot = { rows = rows, money = GetMoney(), totals = M:BagTotals() }
        M:ShowVendor()
    elseif event == "MERCHANT_CLOSED" then
        M:ObserveVendor()
        if M.vendorRun and M.vendorRun.phase == "selling" then M:VendorUncertain("merchant closed before sale confirmation") end
        M.merchantOpen, M.vendorRun, M.vendorReview = false, nil, nil
        if M.vendorWindow then M.vendorWindow:Hide() end
    else M:ScheduleVendorObservation() end
end)
