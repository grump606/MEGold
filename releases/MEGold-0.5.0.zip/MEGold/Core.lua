local _, M = ...
M.defaults = { batchSize = 10, minProfit = 1, minReturn = 0, maxCost = 100000,
    budget = 1000000, reserve = 0, ignored = {}, neverSell = {}, buyRarities = {}, sellRarities = { [0] = true, [1] = true } }
M.results = {}
M.status = "Open the auction house to scan."
M.events = CreateFrame("Frame")
function M:Refresh()
    if self.Render then self:Render() end
    if self.RenderLedger then self:RenderLedger() end
    if self.RenderVendor then self:RenderVendor() end
end
function M:SetStatus(message, quiet)
    if not quiet and self.LogState then self:LogState("status", message) end
    self.status = message
    self:Refresh()
end
M.events:RegisterEvent("ADDON_LOADED")
M.events:RegisterEvent("AUCTION_HOUSE_SHOW")
M.events:RegisterEvent("AUCTION_HOUSE_CLOSED")
M.events:RegisterEvent("REPLICATE_ITEM_LIST_UPDATE")
M.events:RegisterEvent("GET_ITEM_INFO_RECEIVED")
M.events:SetScript("OnEvent", function(_, event, arg)
    if event == "ADDON_LOADED" and arg == "MEGold" then
        MEGoldDB = MEGoldDB or {}
        MEGoldDB.settings = MEGoldDB.settings or {}
        MEGoldDB.ledger = MEGoldDB.ledger or {}
        M.db = MEGoldDB
        for k, v in pairs(M.defaults) do
            if M.db.settings[k] == nil then M.db.settings[k] = v end
        end
        M:InitializeDiagnostics()
        M:InitializeQueue()
        M:LogState("startup", "Saved character state initialized")
    elseif event == "AUCTION_HOUSE_SHOW" then
        M.ahOpen = true
        M:Show()
    elseif event == "AUCTION_HOUSE_CLOSED" then
        M.ahOpen = false
        M:StopScan()
        M:CloseQueue()
    elseif event == "REPLICATE_ITEM_LIST_UPDATE" then
        M:ReadSnapshot()
    elseif event == "GET_ITEM_INFO_RECEIVED" and M.scan then
        M:RetryPending(arg)
    end
end)
SLASH_MEGOLD1 = "/megold"
SLASH_MEGOLD2 = "/meg"
SlashCmdList.MEGOLD = function(message)
    if message == "demo" then M:Demo()
    elseif message == "ledger" then M:ShowLedger()
    elseif message == "logs" or message == "diagnostics" then M:ShowDiagnostics()
    elseif message == "vendor" then
        if M.merchantOpen then M:ShowVendor() else M:SetStatus("Open a vendor first."); M:Show() end
    else M:Show() end
end
