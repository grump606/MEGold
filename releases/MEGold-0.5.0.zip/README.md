# MEGold

Personal vendor-flip addon for WoW Forever. Version 0.5 adds persistent diagnostics.

## Install

Copy the `MEGold` folder into your Forever client's `Interface/AddOns` folder.
Enable it in the AddOns menu. Interface 16001 targets the known beta API and must be
checked against the launch client. No game installation is modified by this repository.

Open `/meg` or `/megold`. `/meg demo` displays clearly labeled sample deals without
contacting the auction house. Open an auctioneer and press **Scan AH** for real data.
Use **Stop** to cancel local processing. The server may impose a full-scan cooldown.
Hover results for item tooltips; Previous/Next batch shows groups of ten.
Press **Filters** to edit profit, return, purchase cap, budget, reserve, batch size,
and buying rarities. Money fields use copper. Saved filters immediately recheck all
loaded candidates, including previously hidden deals. Confirmed spending counts toward
the character's budget and persists across reloads. **Transactions → Start new budget**
resets spending after the buying batch is finished, while retaining purchase history.
Buying ignore lists and Never Sell lists accept item IDs separated by commas or spaces.
Never Sell IDs exclude items from automatic vendor selling.

## Buying individual item lots

Press **Prepare buying batch** to pause local scanning and select up to the configured
batch size within the remaining budget. Each lot is searched again for a real auction
ID, matching item link/variant and quantity, at no more than its snapshot cost.
Press **Buy Next** for each purchase. Successful server confirmation records the purchase
and refreshes the next deal. **Skip deal** advances past missing or unwanted deals.
Quotes older than ten seconds trigger another search and require a new click.
For commodities, the addon totals available price tiers for the selected quantity.
**Get Quote** requests a firm server quote; **Confirm Buy** purchases it with another click.
The total must remain within the original snapshot price and all current profit/budget
limits. Expired quotes require another request. Changing quotes through another buying
UI invalidates MEGold's quote; conflicted in-flight purchases require manual review.

Transactions are stored under `MEGoldDB.accounts`, keyed by character GUID. Confirmed
purchases record exact links, quantities, costs and timestamps. If a purchase times out,
throws an error, or reloads before confirmation, further buying locks rather than retrying.
A matching late confirmation can resolve it. **Transactions** shows the pending item,
quantity, cost and purchase history. After checking mail, inventory and gold, use
**Verified purchased** or **Verified not purchased** and confirm the review dialog.
Review controls remain disabled while the transaction is still waiting for its response.
Manual decisions are recorded, and confirmed manual purchases count toward the budget.
The addon has not yet been tested in the actual Forever client.

Profit = exact-link vendor unit price × quantity − full lot buyout.
Missing item data stays pending and never becomes a confirmed opportunity.
Listings are snapshots and may already be unavailable.

Demo data cannot enter the purchase queue. This version spends real gold when
**Buy Next** or **Confirm Buy** is clicked and sells reviewed flips at an open merchant.

## Collection and vendor selling

After collecting purchase mail, open **Transactions** (`/meg ledger`) and press
**Collected…** on each purchase you have collected. Confirm the review. The complete
unallocated lot must be present in your bags. This explicit collection step prevents
matching personal items from being treated as an uncollected auction purchase.
Automatic mailbox provenance is not implemented.

**Hold for AH** excludes a purchase from automatic selling. Release its hold when ready.
If items leave your bags outside a verified vendor sale (including bank deposits or
consumption), affected collected purchases are unmarked and held for another review.

Opening a merchant displays **Review vendor flips**; reopen it with `/meg vendor`.
Choose selling rarities (Poor/Common initially), press **Review flips**, and inspect
the exact quantities, expected proceeds and bag locations. Uncheck rows to exclude
them temporarily. **Sell reviewed flips** processes selected stacks sequentially.
Mixed stacks split automatically into a free general-purpose bag slot; personal units
remain in the original stack. If no suitable slot exists, selling stops.
Locked, bound, equipment-set, held, Never Sell and zero-value items are excluded.
Changes to inventory or eligibility stop selling and require another review.

## Profit tally

The main window, Transactions and vendor review show persistent character totals:

- **Flip sale proceeds:** money received from collected tracked purchases.
- **Allocated purchase cost:** FIFO purchase costs assigned to quantities actually sold.
- **Realized flip profit:** flip proceeds minus those costs.
- **Other vendor proceeds:** sales with no collected tracked cost attribution. These are
  proceeds, not claimed profit; they may include untracked or unmarked purchases.

Unsold purchases do not earn profit. Cost allocation conserves integer copper across
partial sales. Vendor buybacks reverse identifiable recorded receipts and restore flip
quantities. Holds prevent automatic sales but do not hide the known cost of a manual sale.
Budget resets do not erase the profit tally or purchase history.

Receipts require matching vendor buyback, bag and gold changes. Repairs, purchases,
loot gold and unmatched money changes are not counted as vendor sales. Ambiguous
activity locks automatic selling and remains excluded from totals. **Review accounting…**
lets you explicitly exclude the unresolved activity and resume: remaining collected
flips are unmarked and held until you verify them. Reloads during a sale also require
review. The tally covers observed activity while MEGold is enabled, not past game history.

## Diagnostic log

Open **Diagnostics** in the main window, or type `/meg logs` (`/meg diagnostics` also works).
Press **Refresh report**, then **Select all / copy** and Ctrl+C to copy the report.
The viewer is a snapshot so incoming events do not interrupt text selection. It also
provides **Pause recording**, **Resume recording**, and **Clear log** controls.

Recording starts enabled. The latest 500 entries are retained in a bounded ring inside
`MEGoldDB.diagnostics`, alongside the other saved settings. WoW writes SavedVariables
on a normal logout or `/reload`; a crash can lose entries not yet written. Paused logging
stays paused through reloads. Clearing the log preserves recording preferences and history
outside diagnostics, including purchases and profit totals.

Reports include addon/client/build/interface versions, auction API capabilities, current
transaction phases, sampled scan progress, search and throttle events, commodity quotes,
purchase intent and confirmation, vendor receipts/buybacks, manual reviews and API errors.
Addon Lua errors after startup are logged while forwarding to the existing error handler.
Routine entries exclude chat and player-name payloads. Error messages and stacks are
included as received and may contain context worth reviewing before sharing.
No report is uploaded automatically. The addon cannot write an arbitrary standalone log file.

For a failed live test: open `/meg logs` promptly, refresh, copy the report, and retain it
before clearing the log or performing many more scans. It is bounded, so older events roll off.

## Validation

Run `python tests/test_rules.py` when the Python `lupa` package is available.
Tests execute the actual Lua rule module against boundary cases.
Run `python tests/test_queue.py` for mocked-server transaction lifecycle checks.
Run `python tests/test_commodities.py` for quote caps, expiry, interference and reconciliation.
Run `python tests/test_vendor.py` for profit allocation, buybacks, splitting and inventory protections.
Run `python tests/test_boot.py` for TOC startup and UI wiring with frame doubles.
Run `python tests/test_diagnostics.py` for log retention, pause/clear, persistence and error forwarding.
Tests run actual addon modules under Lua 5.1. UI doubles do not establish live visual quality.
Live-client scan and visual validation are still required.
